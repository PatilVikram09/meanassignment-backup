export class User{

    constructor(
        public userId: number,
        public userName: string,
        public email: string,
        public password: string,
        public roleId: number
    ){}
}
